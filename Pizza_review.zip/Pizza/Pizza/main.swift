//
//  main.swift
//  Pizza
//
//  Created by Egor on 10.07.2019.
//  Copyright © 2019 Egor. All rights reserved.
//

import Foundation

let cheeseburger = Pizza(identifier: 1, name: "Чизбургер-пицца", ingredients: [.butter, .meat], price: 375)
let crazy = Pizza(identifier: 2, name: "Крэйзи пепперони", ingredients: [.butter, .cucumber], price: 3175)
let tomyam = Pizza(identifier: 3, name: "Пицца Том Ям", ingredients: [.meat], price: 425)

let pizzaBox = [cheeseburger, crazy, tomyam]

showMenu(box: pizzaBox)

let pizzaNumber = readPizzaNumber()
let address = readAddress()

printCheck(pizzaNumber: pizzaNumber, box: pizzaBox, address: address)
