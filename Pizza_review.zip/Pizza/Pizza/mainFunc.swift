//
//  zakaz.swift
//  Pizza
//
//  Created by Egor on 14.07.2019.
//  Copyright © 2019 Egor. All rights reserved.
//

import Foundation

// Посмотри какой-нибудь code style для Swift, и уделяй внимание пробельчикам.
func showMenu(box: [Pizza]) {
    print("КОНСОЛЬ ПИЦЦА\n")
    // Я заменил обычный цикл for на forEach.
    box.forEach { print($0.description) }
}

func readPizzaNumber() -> Int {
    // На самом деле, можно было бы просто выйти из приложения, если мы не ввели данные, но оставим так.
    while true {
        print("Выберите пиццу и введите её номер")
        if let inputLine = readLine(strippingNewline: true), !inputLine.isEmpty, let number = Int(inputLine) {
            return number
        } else {
            print("Ввод данных является обязательным шагом.")
        }
    }
}

func readAddress() -> String {
    // На самом деле, можно было бы просто выйти из приложения, если мы не ввели данные, но оставим так.
    while true {
        print("Введите адрес доставки")
        if let inputLine = readLine(strippingNewline: true), !inputLine.isEmpty {
            return inputLine
        } else {
            print("Ввод данных является обязательным шагом.")
        }
    }
}


func printCheck(pizzaNumber: Int, box: [Pizza], address: String) {
    guard let pizza = box.first(where: { $0.identifier == pizzaNumber }) else {
        assertionFailure("Введённого номера пиццы в нашем ассортименте нет.")
        return
    }

    print("\nВаш заказ:\n"
        .appending("\(pizza.name)\n")
        .appending("Цена: \(pizza.price)\n")
        .appending("Адрес доставки: \(address)\n")
        .appending("Спасибо за заказ, мы вам перезвоним."))
}
