//
//  pizza_main.swift
//  Pizza
//
//  Created by Egor on 14.07.2019.
//  Copyright © 2019 Egor. All rights reserved.
//

import Foundation

// Для перечисления возможных ингредиентов лучше использовать enum
// ": String" означает, что у каждого элемента перечисления будет строковое значение, которое можно получить через rawValue.
enum Ingredient: String {
    case meat = "Мясо"
    case butter = "Масло"
    case potato = "Картошка"
    case cucumber = "Огурцы"
}

// Если от класса не собираемся наследоваться, то лучше всегда ставить final в самое начало.
// Вместо private(set) здесь нужно использовать let, так как значения нигде не будут меняться в дальнейшем.
// Вместо строки consist теперь массив ингредиентов.
// Цена не может быть отрицательной и поэтому лучше использовать беззнаковый тип UInt.
// Вместо функции show() лучше сделать вычисляемую переменную description.
final class Pizza {
    let identifier: Int
    let name: String
    let ingredients: [Ingredient]
    let price: UInt

    var description: String {
        return "\(identifier): \(name)\n"
            .appending("Состав: \(ingredients)\n")
            .appending("Цена: \(price)\n")
    }

    init(identifier: Int, name: String, ingredients: [Ingredient], price: UInt) {
        self.identifier = identifier
        self.name = name
        self.ingredients = ingredients
        self.price = price
    }
}
