//
//  zakaz.swift
//  Pizza
//
//  Created by Egor on 14.07.2019.
//  Copyright © 2019 Egor. All rights reserved.
//

import Foundation

//вывод меню
func showMenu(box:[Pizza]){
    print("КОНСОЛЬ ПИЦЦА\n")
    for elem in box{
        elem.show()
    }
}

//получение номера пиццы
func getPizzaNumber() -> String {
    //чтоб не ругался компилятор
    var result: String = "Дефолтный адрес"
    
    while true {
        print("Выберите пиццу и введите ее номер")
        if let pizzaNumber = readLine(strippingNewline: true){
            if pizzaNumber == ""{
                print("Вы не ввели номер пиццы")
            }else{
                result = pizzaNumber
                break
            }
        }
    }
    return result
}

//получение адреса
func getAddress() -> String {
    var clientAddress: String = "Дефолтный адрес"
    
    while true {
        print("Введите адрес доставки")
        if let address = readLine(strippingNewline: true){
            if address == ""{
                print("Вы не ввели адрес доставки")
            }else{
                clientAddress = address
                break
            }
        }
    }
    return clientAddress
}

//печать чека
func printCheck(number: String, box:[Pizza], clientAddress: String) {
    
    for pizza in box{
        if pizza.id == Int(number) {
            print("\nВаш заказ:\n \(pizza.name)\n Цена: \(pizza.price)\n Адрес доставки: \(address)\n\n Спасибо за заказ, мы вам перезвоним ))")
        }
    }
}
