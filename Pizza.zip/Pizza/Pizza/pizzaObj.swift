//
//  pizza_main.swift
//  Pizza
//
//  Created by Egor on 14.07.2019.
//  Copyright © 2019 Egor. All rights reserved.
//

import Foundation

//класс пиццы
class Pizza {
    private (set) var id: Int
    private (set) var name: String
    private (set) var consist: String
    private (set) var price: Int
    
    init(id:Int, name:String, consist: String, price:Int) {
        self.id = id
        self.name = name
        self.consist = consist
        self.price = price
    }
    public func show() {
        print("\(self.id) \(self.name) \n Состав: \(self.consist) \n Цена: \(self.price) \n")
    }
}



