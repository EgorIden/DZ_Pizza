//
//  main.swift
//  Pizza
//
//  Created by Egor on 10.07.2019.
//  Copyright © 2019 Egor. All rights reserved.
//

import Foundation

//пиццы
var cheeseburger = Pizza(id: 1, name: "Чизбургер-пицца", consist: "Соус бургер, мясной соус болоньезе, красный лук", price: 375)
var crazy = Pizza(id: 2, name: "Крэйзи пепперони", consist: "Пикантная пепперони, цыпленок, моцарелла, томатный соус", price: 375)
var tomyam = Pizza(id: 3, name: "Пицца Том Ям", consist: "Соус том ям, креветки, шампиньоны , томаты, сладкий перец, цыпленок", price: 425)

//массив
var pizzaBox = [cheeseburger,crazy,tomyam]

//вывод меню
showMenu(box: pizzaBox)

//получение номера пиццы
var pizzaNumber = getPizzaNumber()

//получение адреса
var address = getAddress()

//печать чека
printCheck(number: pizzaNumber, box: pizzaBox, clientAddress: address)

